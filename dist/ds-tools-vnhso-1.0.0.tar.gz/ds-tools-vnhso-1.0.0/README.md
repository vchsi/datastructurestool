# Example Package

It helps with data structures! Over five easy-to-use data structure shells and functions for them.